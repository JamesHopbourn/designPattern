package factoryPattern;

public interface Computer {
    public String model();
}
