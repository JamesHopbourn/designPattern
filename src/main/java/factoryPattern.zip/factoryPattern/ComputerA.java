package factoryPattern;

public class ComputerA implements Computer {
    @Override
    public String model() {
        return "model A";
    }
}
