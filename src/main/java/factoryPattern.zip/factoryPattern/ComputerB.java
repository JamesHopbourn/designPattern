package factoryPattern;

public class ComputerB implements Computer{
    @Override
    public String model() {
        return "model B";
    }
}
