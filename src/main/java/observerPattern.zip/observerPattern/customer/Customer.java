package observerPattern.customer;

public abstract class Customer {
    public abstract void update();
}
