package proxyPattern;

public interface House {
    public void findHouse();
}
