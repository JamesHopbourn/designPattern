package proxyPattern;

public class James implements House{
    @Override
    public void findHouse() {
        System.out.println("找房子");
    }
}
