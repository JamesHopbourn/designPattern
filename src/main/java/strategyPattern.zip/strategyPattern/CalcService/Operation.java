package strategyPattern.CalcService;

public interface Operation {
    int doCalc(int num1, int num2);
}
