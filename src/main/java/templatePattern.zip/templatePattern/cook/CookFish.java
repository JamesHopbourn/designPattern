package templatePattern.cook;

public class CookFish extends Cook{
    @Override
    public void doCook() {
        System.out.println("开始做水煮活鱼");
    }
}
