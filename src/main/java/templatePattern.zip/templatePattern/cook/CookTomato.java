package templatePattern.cook;

public class CookTomato extends Cook{
    @Override
    public void doCook() {
        System.out.println("开始做西红柿炒鸡蛋");
    }
}
